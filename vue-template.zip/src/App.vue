<template>
  <div class="app">
    <h1>Simple URL Shortner</h1>
    <input type="url" name="url">
  <div class="short-url">
  paste link above to shorten it
  </div>
  <button>shorten</button>
    
  </div>
  
</template>

<script>


export default {
  name: "App",
 
};
</script>

<style>
body{
  background: #f8f8f8;
}
.app{
  font-family:"Roboto",Sans-serif;
  text-align: center;
  border:none;
  
 
}
h1{
  text-transform:uppercase;
  font-weight:300;
  font-size:42px;
  line-height:1em;
  color:#16DBA6;
  margin: 0 0 60px 0;

}
</style>
